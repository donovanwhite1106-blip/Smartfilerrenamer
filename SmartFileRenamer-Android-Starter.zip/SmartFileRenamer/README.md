# Smart File Renamer Android — v0.8.0 YGOPRODeck card matching

This version is designed for Yu-Gi-Oh! card-image folders such as `Folder 1.zip` (4,468 JPG files, most named with numeric image IDs).

## What changed

- Uses the free YGOPRODeck v7 card catalog: `https://db.ygoprodeck.com/api/v7/cardinfo.php`.
- Maps numeric filenames to `card_images[].id`, which covers alternate artwork image IDs as well as standard artwork.
- For non-numeric filenames, only normalizes names that exactly match a catalog card name after punctuation/case normalization.
- Does **not** use ML Kit's generic image labels or Google Cloud Vision. No paid image API, API key, or per-image charge is required.
- Downloads the catalog once and caches it locally for up to seven days. A saved stale catalog can be used offline if refreshing fails.
- Unknown IDs and unmatched names are left unchanged. There is no fallback to guessed labels such as “poster”.
- Defaults to **Preview only — do not change files**. Preview runs show how many files would be renamed without modifying the selected folder. Turn preview off only after reviewing results and testing a small batch.
- Alternate artworks resolving to the same card name receive a numbered suffix to avoid generating identical target names within the batch.
- Existing file-access checks, background progress, and verified rename reporting remain in place.

## First test on a phone

1. Install the APK produced by the repository's GitHub Actions build.
2. Open Smart File Renamer and keep **Preview only — do not change files** checked.
3. Choose **Pick files** and select only 5 numeric JPG images from the extracted card folder. You can also pick a folder, but a five-file test is recommended first.
4. Start the run and wait for the completion notification. The first run needs internet access to download the catalog; later runs use the cached catalog.
5. Review the preview's proposed names. If the catalog cannot be downloaded, the app should leave images unchanged and report that reason.
6. Only after the preview names are correct, select a small backed-up test batch and turn preview off. Do not start with all 4,468 files until the small test is satisfactory.

## Build

The project is nested under `SmartFileRenamer/` for the repository's existing workflow, which unpacks `SmartFileRenamer-Android-Starter.zip`, then runs `gradle assembleDebug` on Java 17. The debug APK is uploaded as the `SmartFileRenamer-APK` workflow artifact.

## Important limitations

- The app currently identifies images by the filename's numeric YGOPRODeck image ID or an exact card-name match. It does **not** yet perform visual similarity matching on arbitrary images with unrelated filenames.
- The supplied archive has 4,468 JPG files, 4,429 with numeric basenames and 39 with non-numeric names. The catalog mapping should cover the numeric ones only when their basename matches a YGOPRODeck `card_images[].id` value. Non-matches are deliberately not guessed.
- This source package has been statically inspected and ZIP integrity can be checked locally, but it has **not** been compiled with Gradle or tested on a physical Android device in this environment. The GitHub Actions build and the first on-device preview are still required before a real rename run.

## Reference

YGOPRODeck API Guide: https://ygoprodeck.com/api-guide/
The API guide recommends caching the catalog and image data locally, and warns against repeatedly hotlinking image files. This implementation requests the catalog only and caches its response; it does not download every card image.
