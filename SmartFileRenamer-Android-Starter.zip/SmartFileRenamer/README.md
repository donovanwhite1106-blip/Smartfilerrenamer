# Smart File Renamer — Android starter project

Native Kotlin + Jetpack Compose Android Studio scaffold.

## Present in this starter
- Android multi-file picker and single-file picker
- Storage Access Framework folder selection (URI selection only; recursive traversal is not implemented yet)
- WorkManager background-work scaffold with foreground notification and progress reporting
- Safe filename-heuristic utility
- Gradle Android project configuration

## Important status
This is an **early starter project, not a finished app or installable APK**. The worker currently analyzes selected URI names and reports progress. It does not yet rename files, unpack/repack ZIP archives, recursively traverse selected folders, call Google or another online search service, or create the final ZIP export.

The completed workflow should copy files into app-private staging, identify them, create collision-safe names, and export a ZIP so original files remain untouched.

## Online identification architecture
Google Search is not a universal raw-file identification API. A robust implementation should combine:
- Web search integration for text and known titles (provider API access/quotas may apply)
- Image matching or visual-similarity integration for pictures/artwork
- Metadata and text extraction for PDFs, office docs, audio/video, archives, and binaries
- Hash lookup for exact matches where a known-file database exists

Do not embed private API keys in the APK. Use a backend or secure user-configured credential flow. The requested best-guess mode should keep an audit manifest and avoid overwriting originals.

## Build in Android Studio
1. Install Android Studio and JDK 17.
2. Open this directory as an existing project.
3. Allow Gradle sync and install required SDK 35 components.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Next milestones
1. Recursive SAF folder traversal and robust URI streaming.
2. ZIP extraction with path traversal and decompression-bomb protections.
3. File fingerprinting and format-specific metadata/text extraction.
4. Backend adapter for web search and image matching.
5. Candidate ranking, filename sanitization, extension preservation, collision resolution.
6. ZIP export with original-to-new-name manifest.
7. Results/history screen, cancellation/retry, and tests.
