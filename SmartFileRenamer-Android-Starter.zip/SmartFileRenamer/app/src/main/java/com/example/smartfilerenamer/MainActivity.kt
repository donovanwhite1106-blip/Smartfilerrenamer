package com.example.smartfilerenamer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val selected = mutableStateListOf<Uri>()
    private var status by mutableStateOf("Choose files, a folder, or a ZIP to begin.")

    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            if (uri !in selected) selected.add(uri)
        }
        status = "${selected.size} item(s) queued."
    }
    private val pickOne = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            if (it !in selected) selected.add(it)
            status = "${selected.size} item(s) queued."
        }
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            if (it !in selected) selected.add(it)
            status = "Folder URI selected. Recursive folder processing is not yet implemented in this starter."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Smart File Renamer", style = MaterialTheme.typography.headlineMedium)
                        Text("Identify files online, generate useful names, and export a renamed ZIP.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { pickFiles.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Pick multiple") }
                            OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.weight(1f)) { Text("Pick folder") }
                        }
                        OutlinedButton(onClick = { pickOne.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Pick one file or ZIP") }
                        Text("Selected items: ${selected.size}", style = MaterialTheme.typography.titleMedium)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(selected) { uri ->
                                Card(Modifier.fillMaxWidth()) { Text(uri.lastPathSegment ?: uri.toString(), Modifier.padding(12.dp), maxLines = 2) }
                            }
                        }
                        Text(status)
                        Button(onClick = { startBackgroundJob() }, enabled = selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Start background scan") }
                        OutlinedButton(onClick = { selected.clear(); status = "Selection cleared." }, modifier = Modifier.fillMaxWidth()) { Text("Clear selection") }
                        Text("Starter scaffold only: online lookup, actual renaming, ZIP extraction/export, and recursive folder walking still need implementation.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    private fun startBackgroundJob() {
        val input = workDataOf("uris" to selected.map(Uri::toString).toTypedArray())
        val request = OneTimeWorkRequestBuilder<RenameWorker>()
            .setInputData(input)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("smart-renamer")
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("smart-renamer-${System.currentTimeMillis()}", ExistingWorkPolicy.KEEP, request)
        status = "Background scan queued. Progress is available through the job notification and WorkManager status."
    }
}
