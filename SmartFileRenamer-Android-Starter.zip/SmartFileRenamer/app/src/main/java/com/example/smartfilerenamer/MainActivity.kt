package com.example.smartfilerenamer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.core.content.FileProvider
import androidx.work.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val selected = mutableStateListOf<Uri>()
    private var status by mutableStateOf("Choose files or a folder, then tap Rename selected items.")
    private var previewOnly by mutableStateOf(true)
    private var lastCrashReport by mutableStateOf("")
    private var exporting by mutableStateOf(false)
    private var lastExportUri by mutableStateOf<Uri?>(null)
    private var showProgressPage by mutableStateOf(false)
    private var liveProgress by mutableStateOf(0)
    private var liveProgressMessage by mutableStateOf("No rename job is currently running.")
    private var liveJobState by mutableStateOf("No job started")
    private var liveProcessed by mutableIntStateOf(0)
    private var liveTotal by mutableIntStateOf(0)
    private var liveRenamed by mutableIntStateOf(0)
    private var liveUnchanged by mutableIntStateOf(0)
    private var liveFailed by mutableIntStateOf(0)

    private val createExport = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { destination ->
        if (destination == null) {
            status = "Export cancelled."
        } else {
            exportSelected(destination)
        }
    }

    private val pickFiles = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        // Keep provider-specific failures from escaping the picker callback and crashing the Activity.
        try {
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                val found = mutableListOf<Uri>()
                data?.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) {
                        runCatching { clip.getItemAt(i).uri }.getOrNull()?.let { if (it !in found) found.add(it) }
                    }
                }
                data?.data?.let { if (it !in found) found.add(it) }
                val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                found.forEach { uri ->
                    if (flags != 0) runCatching { contentResolver.takePersistableUriPermission(uri, flags) }
                    if (uri !in selected) selected.add(uri)
                }
                runCatching { persistSelection() }
                status = if (found.isEmpty()) "No file URI was returned by Android. Try Pick files again." else "${selected.size} item(s) selected."
            }
        } catch (e: Exception) {
            status = "Could not add the selected file: ${e.message ?: e.javaClass.simpleName}. Try selecting it again."
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            if (it !in selected) selected.add(it)
            persistSelection()
            status = "Folder selected. Files inside it and subfolders will be processed."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Record fatal runtime exceptions so repeated crashes can be diagnosed from the phone
        // without requiring ADB or developer tools.
        val crashPrefs = getSharedPreferences("smart_renamer", MODE_PRIVATE)
        lastCrashReport = crashPrefs.getString("last_crash_report", "").orEmpty()
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val report = buildString {
                    appendLine("Smart File Renamer crash report")
                    appendLine("App version: 0.8.0 (YGOPRODeck card ID matching)")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Exception: ${throwable.javaClass.name}: ${throwable.message}")
                    appendLine()
                    throwable.printStackTrace(java.io.PrintWriter(java.io.StringWriter()).also { writer ->
                        // Stack trace is appended below using the standard printStackTrace output.
                    })
                    val writer = java.io.StringWriter()
                    throwable.printStackTrace(java.io.PrintWriter(writer))
                    append(writer.toString())
                }
                crashPrefs.edit().putString("last_crash_report", report).commit()
            } catch (_: Throwable) { }
            previousHandler?.uncaughtException(thread, throwable)
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        val prefs = getSharedPreferences("smart_renamer", MODE_PRIVATE)
        previewOnly = prefs.getBoolean("preview_only", true)
        prefs.getString("selected_uris", null)?.split("\n")?.filter { it.isNotBlank() }?.forEach { raw ->
            runCatching { selected.add(Uri.parse(raw)) }
        }
        WorkManager.getInstance(this).getWorkInfosByTagLiveData("smart-renamer").observe(this) { infos ->
            val info = infos?.firstOrNull { !it.state.isFinished } ?: infos?.firstOrNull()
            if (info != null) {
                liveJobState = info.state.name.lowercase().replaceFirstChar { it.uppercase() }
                liveProgress = info.progress.getInt("progress", if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0).coerceIn(0, 100)
                liveProcessed = info.progress.getInt("processed", info.outputData.getInt("processed", 0))
                liveTotal = info.progress.getInt("total", info.outputData.getInt("total", 0))
                liveRenamed = info.progress.getInt("renamed", info.outputData.getInt("renamed", 0))
                liveUnchanged = info.progress.getInt("unchanged", info.outputData.getInt("unchanged", 0))
                liveFailed = info.progress.getInt("failed", info.outputData.getInt("failed", 0))
                liveProgressMessage = info.progress.getString("message")
                    ?: info.outputData.getString("message")
                    ?: info.outputData.getString("error")
                    ?: when (info.state) {
                        WorkInfo.State.ENQUEUED -> "Rename job queued; waiting to start."
                        WorkInfo.State.RUNNING -> "Rename job is running. Scanning files may take a little while."
                        WorkInfo.State.SUCCEEDED -> "Rename job finished."
                        WorkInfo.State.FAILED -> "Rename job failed. Check the notification for details."
                        WorkInfo.State.CANCELLED -> "Rename job cancelled."
                        WorkInfo.State.BLOCKED -> "Rename job is waiting."
                    }
            }
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Smart File Renamer", style = MaterialTheme.typography.headlineMedium)
                        if (lastCrashReport.isNotBlank()) {
                            OutlinedButton(onClick = {
                                runCatching {
                                    val clipboard = getSystemService(android.content.ClipboardManager::class.java)
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Smart File Renamer crash report", lastCrashReport))
                                    status = "Crash report copied. Paste it into your support message."
                                }.onFailure { status = "Could not copy crash report: ${it.message ?: it.javaClass.simpleName}" }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Copy last crash report for diagnosis") }
                            Text("A previous app crash was recorded. Copy this report and send it for diagnosis.", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { showProgressPage = false }, modifier = Modifier.weight(1f)) { Text("Select Files") }
                            Button(onClick = { showProgressPage = true }, modifier = Modifier.weight(1f)) { Text("Currently Renaming") }
                        }
                        if (showProgressPage) {
                            Text("Currently Renaming", style = MaterialTheme.typography.titleLarge)
                            Text(liveJobState, style = MaterialTheme.typography.titleMedium)
                            LinearProgressIndicator(progress = { liveProgress / 100f }, modifier = Modifier.fillMaxWidth())
                            Text(if (liveTotal > 0) "$liveProcessed of $liveTotal files completed" else "Preparing file list…", style = MaterialTheme.typography.titleMedium)
                            Text("${if (previewOnly) "Would rename" else "Renamed"}: $liveRenamed · Unchanged: $liveUnchanged · Failed: $liveFailed")
                            Text(liveProgressMessage)
                            Text("Renaming continues in the background if you leave this screen or switch apps. Return here to check progress and the final result.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { showProgressPage = false }, modifier = Modifier.fillMaxWidth()) { Text("Back to file selection") }
                        } else {
                            Text("Choose files or a folder. Renaming continues in the background if you leave the app.")
                            Text("Yu-Gi-Oh! card matching", style = MaterialTheme.typography.titleMedium)
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Checkbox(checked = previewOnly, onCheckedChange = { enabled ->
                                    previewOnly = enabled
                                    getSharedPreferences("smart_renamer", MODE_PRIVATE).edit().putBoolean("preview_only", enabled).apply()
                                    status = if (enabled) "Preview mode is ON. The app will show proposed card names without changing any files." else "Preview mode is OFF. A run can rename files; test a small batch first."
                                })
                                Column(Modifier.weight(1f)) {
                                    Text("Preview only — do not change files", style = MaterialTheme.typography.bodyLarge)
                                    Text("Recommended for your first test. Turn this off only after reviewing the proposed names.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Text("The app uses the free YGOPRODeck catalog to match numeric image IDs and exact card names, including alternate artwork IDs. The catalog is cached on this phone. Unmatched images are left unchanged; no generic labels or paid image API are used.", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { launchFilePicker() }, modifier = Modifier.weight(1f)) { Text("Pick files") }
                                OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.weight(1f)) { Text("Pick folder") }
                            }
                            Text("Selected items: ${selected.size}", style = MaterialTheme.typography.titleMedium)
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(selected.toList()) { uri ->
                                    // Do not let an unusual document provider crash Compose while drawing the selection list.
                                    val label = remember(uri) { safeDisplayName(uri) }
                                    Card(Modifier.fillMaxWidth()) { Text(label, Modifier.padding(12.dp), maxLines = 2) }
                                }
                            }
                            Text(status)
                            Button(onClick = { startRenameJob() }, enabled = selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Rename selected items") }
                            OutlinedButton(onClick = { createExport.launch("renamed-files.zip") }, enabled = selected.isNotEmpty() && !exporting, modifier = Modifier.fillMaxWidth()) { Text(if (exporting) "Exporting files…" else "Save / Export selected files as ZIP") }
                            OutlinedButton(onClick = { shareSelectedFiles() }, enabled = selected.isNotEmpty() && !exporting, modifier = Modifier.fillMaxWidth()) { Text(if (exporting) "Preparing files…" else "Share renamed files / Email") }
                            OutlinedButton(onClick = { openSelectedImageForLens() }, enabled = selected.size == 1 && isImageUri(selected.first()) && !exporting, modifier = Modifier.fillMaxWidth()) { Text("Try Google Lens with selected image") }
                            OutlinedButton(onClick = { selected.clear(); persistSelection(); status = "Selection cleared." }, modifier = Modifier.fillMaxWidth()) { Text("Clear selection") }
                            Text("Lens test: select exactly one image, then try sharing it to Google Lens or Google Photos if your phone offers that option. This is a manual helper, not automatic batch matching.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }


    private fun isImageUri(uri: Uri): Boolean {
        return runCatching { contentResolver.getType(uri)?.startsWith("image/") == true }.getOrDefault(false)
    }

    private fun openSelectedImageForLens() {
        val uri = selected.singleOrNull()
        if (uri == null || !isImageUri(uri)) {
            status = "Select exactly one image file first. Folders and non-image files cannot be sent to Lens."
            return
        }
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = contentResolver.getType(uri) ?: "image/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = android.content.ClipData.newUri(contentResolver, safeDisplayName(uri), uri)
            }
            status = "Choose Google Lens or Google Photos if it appears. If neither accepts the image, open the Google app and upload the image manually."
            startActivity(Intent.createChooser(send, "Search this image with Google Lens"))
        } catch (e: Exception) {
            status = "Could not share this image to Lens: ${e.message ?: e.javaClass.simpleName}. Try opening it in Google Photos and tapping Lens."
        }
    }

    private fun safeDisplayName(uri: Uri): String {
        return try {
            val treeName = runCatching {
                if (android.provider.DocumentsContract.isTreeUri(uri)) DocumentFile.fromTreeUri(this, uri)?.name else null
            }.getOrNull()
            val singleName = runCatching { DocumentFile.fromSingleUri(this, uri)?.name }.getOrNull()
            treeName ?: singleName ?: uri.lastPathSegment ?: "Selected file"
        } catch (_: Throwable) {
            "Selected file (${uri.lastPathSegment ?: "name unavailable"})"
        }
    }

    private fun launchFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        pickFiles.launch(intent)
    }

    private data class ExportItem(val file: DocumentFile, val path: String)

    private fun exportSelected(destination: Uri) {
        if (exporting) return
        exporting = true
        status = "Preparing and checking ZIP export…"
        val selectedSnapshot = selected.toList()
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                val tempZip = java.io.File(cacheDir, "renamed-files-export-${System.currentTimeMillis()}.zip")
                try {
                    val items = mutableListOf<ExportItem>()
                    val visited = mutableSetOf<String>()
                    selectedSnapshot.forEach { uri ->
                        val item = if (android.provider.DocumentsContract.isTreeUri(uri)) {
                            DocumentFile.fromTreeUri(this@MainActivity, uri)
                        } else {
                            DocumentFile.fromSingleUri(this@MainActivity, uri)
                        }
                        if (item != null) {
                            val prefix = if (item.isDirectory) (item.name ?: "folder") else ""
                            collectForExport(item, prefix, items, visited)
                        }
                    }
                    if (items.isEmpty()) throw IllegalStateException(
                        "No files could be found to export. The selected folder may no longer be accessible. Please reselect it and try again."
                    )

                    var exported = 0
                    var skipped = 0
                    val examples = mutableListOf<String>()
                    val usedPaths = mutableSetOf<String>()
                    java.io.FileOutputStream(tempZip).use { raw ->
                        ZipOutputStream(raw).use { zip ->
                            items.forEach { entry ->
                                val safePath = entry.path.replace('\\', '/').trimStart('/')
                                if (safePath.isNotBlank()) {
                                    // Open the source before creating a ZIP entry. This avoids leaving
                                    // half-written entries when Android's document provider denies access.
                                    val input = runCatching { contentResolver.openInputStream(entry.file.uri) }.getOrNull()
                                    if (input == null) {
                                        skipped++
                                        if (examples.size < 4) examples.add("${entry.file.name ?: safePath}: couldn't open file")
                                    } else {
                                        input.use { source ->
                                            var entryPath = safePath
                                            var suffix = 2
                                            while (!usedPaths.add(entryPath)) {
                                                val slash = safePath.lastIndexOf('/')
                                                val dot = safePath.lastIndexOf('.').takeIf { it > slash } ?: safePath.length
                                                entryPath = safePath.substring(0, dot) + " ($suffix)" + safePath.substring(dot)
                                                suffix++
                                            }
                                            zip.putNextEntry(ZipEntry(entryPath))
                                            source.copyTo(zip)
                                            zip.closeEntry()
                                            exported++
                                        }
                                    }
                                }
                            }
                        }
                    }
                    check(exported > 0) {
                        "No files could be read for export. Re-select the file or folder and try again."
                    }
                    // Validate the completed local archive before writing anything to Android's
                    // destination provider. This catches empty or malformed ZIP output early.
                    java.util.zip.ZipFile(tempZip).use { archive ->
                        check(archive.entries().hasMoreElements()) { "The ZIP was empty; no files were added." }
                    }
                    contentResolver.openOutputStream(destination, "w")?.use { output ->
                        tempZip.inputStream().use { input -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Android could not open the destination for writing.")
                    "Export verified: $exported files saved to ZIP; $skipped skipped." +
                        if (examples.isEmpty()) "" else " Examples: ${examples.joinToString(" | ")}"
                } catch (e: Exception) {
                    // CreateDocument creates an empty placeholder before this callback runs. Remove
                    // that placeholder on failure where the document provider allows it.
                    runCatching { android.provider.DocumentsContract.deleteDocument(contentResolver, destination) }
                    "Export failed: ${e.message ?: e.javaClass.simpleName}. No valid ZIP was saved."
                } finally {
                    runCatching { tempZip.delete() }
                }
            }
            exporting = false
            if (result.startsWith("Export verified:")) lastExportUri = destination
            status = result
        }
    }

    private fun shareSelectedFiles() {
        if (exporting || selected.isEmpty()) return
        exporting = true
        status = "Preparing renamed files to share…"
        val selectedSnapshot = selected.toList()
        lifecycleScope.launch {
            val sharedFile = withContext(Dispatchers.IO) {
                runCatching {
                    val items = mutableListOf<ExportItem>()
                    val visited = mutableSetOf<String>()
                    selectedSnapshot.forEach { uri ->
                        val item = if (android.provider.DocumentsContract.isTreeUri(uri)) DocumentFile.fromTreeUri(this@MainActivity, uri)
                                   else DocumentFile.fromSingleUri(this@MainActivity, uri)
                        if (item != null) collectForExport(item, item.name?.takeIf { item.isDirectory }.orEmpty(), items, visited)
                    }
                    check(items.isNotEmpty()) { "No accessible files found to share." }
                    val shareDir = java.io.File(cacheDir, "shared_exports")
                    if (!shareDir.exists()) check(shareDir.mkdirs()) { "Could not prepare temporary export folder." }
                    val zipFile = java.io.File(shareDir, "renamed-files.zip")
                    var exported = 0
                    val usedPaths = mutableSetOf<String>()
                    java.io.FileOutputStream(zipFile).use { raw ->
                        ZipOutputStream(raw).use { zip ->
                            items.forEach { entry ->
                                val safePath = entry.path.replace('\\', '/').trimStart('/')
                                if (safePath.isNotBlank()) {
                                    val input = contentResolver.openInputStream(entry.file.uri)
                                        ?: throw IllegalStateException("Could not open ${entry.file.name ?: safePath}.")
                                    input.use { source ->
                                        var entryPath = safePath
                                        var suffix = 2
                                        while (!usedPaths.add(entryPath)) {
                                            val slash = safePath.lastIndexOf('/')
                                            val dot = safePath.lastIndexOf('.').takeIf { it > slash } ?: safePath.length
                                            entryPath = safePath.substring(0, dot) + " ($suffix)" + safePath.substring(dot)
                                            suffix++
                                        }
                                        zip.putNextEntry(ZipEntry(entryPath))
                                        source.copyTo(zip)
                                        zip.closeEntry()
                                    }
                                    exported++
                                }
                            }
                        }
                    }
                    check(exported > 0) { "No files could be added to the share ZIP." }
                    zipFile
                }.getOrNull()
            }
            exporting = false
            if (sharedFile == null) {
                status = "Could not prepare files to share. Check that the selected files are still accessible."
                return@launch
            }
            try {
                val shareUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", sharedFile)
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_STREAM, shareUri)
                    putExtra(Intent.EXTRA_SUBJECT, "Renamed files")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = android.content.ClipData.newUri(contentResolver, "Renamed files ZIP", shareUri)
                }
                startActivity(Intent.createChooser(sendIntent, "Share renamed files"))
                status = "Share menu opened. Choose Gmail, another email app, or another sharing app."
            } catch (e: Exception) {
                status = "Could not open sharing apps: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    private fun collectForExport(item: DocumentFile, prefix: String, output: MutableList<ExportItem>, visited: MutableSet<String>) {
        val key = item.uri.toString()
        if (!visited.add(key)) return
        if (item.isDirectory) {
            val children = item.listFiles()
            children.forEach { child ->
                val childName = child.name ?: "unnamed-file"
                val path = if (prefix.isBlank()) childName else "$prefix/$childName"
                collectForExport(child, path, output, visited)
            }
        } else {
            val path = prefix.ifBlank { item.name ?: "unnamed-file" }
            output.add(ExportItem(item, path))
        }
    }

    private fun persistSelection() {
        getSharedPreferences("smart_renamer", MODE_PRIVATE).edit()
            .putString("selected_uris", selected.joinToString("\n") { it.toString() })
            .apply()
    }

    private fun startRenameJob() {
        if (selected.isEmpty()) {
            status = "Choose files or a folder first."
            return
        }
        try {
            val jobKey = "job_" + java.util.UUID.randomUUID().toString()
            // Keep potentially many URIs out of WorkManager's 10 KB Data payload limit.
            getSharedPreferences("smart_renamer", MODE_PRIVATE).edit()
                .putString(jobKey, selected.joinToString("\n") { it.toString() })
                .apply()
            val request = OneTimeWorkRequestBuilder<RenameWorker>()
                .setInputData(workDataOf("jobKey" to jobKey))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .addTag("smart-renamer")
                .build()
            WorkManager.getInstance(this).enqueueUniqueWork("smart-renamer-${System.currentTimeMillis()}", ExistingWorkPolicy.KEEP, request)
            showProgressPage = true
            liveJobState = "Enqueued"
            liveProgress = 0
            liveProgressMessage = "Job queued. Scanning selected files…"
            status = if (previewOnly) "Preview started. The app will check card IDs and names without changing any files." else "Rename started. Only confirmed YGOPRODeck card matches will be renamed; unmatched images stay unchanged."
        } catch (e: Exception) {
            status = "Could not start rename job: ${e.message ?: e.javaClass.simpleName}"
        }
    }
}
