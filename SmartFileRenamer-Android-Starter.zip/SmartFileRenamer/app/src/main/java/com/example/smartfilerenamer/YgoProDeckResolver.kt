package com.example.smartfilerenamer

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Resolves numeric image filenames using YGOPRODeck's card-image IDs, including alternate artwork.
 * It does not guess from generic on-device image labels and never renames an unrecognized image.
 * The catalog response is cached locally and refreshed at most once per week.
 */
object YgoProDeckResolver {
    private const val CATALOG_URL = "https://db.ygoprodeck.com/api/v7/cardinfo.php"
    private const val CACHE_NAME = "ygoprodeck-cardinfo-v7.json"
    private val imageExtensions = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "tif", "tiff")

    fun isImage(filename: String): Boolean = filename.substringAfterLast('.', "").lowercase(Locale.ROOT) in imageExtensions
    private const val MAX_CACHE_AGE_MS = 7L * 24L * 60L * 60L * 1000L

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(150, TimeUnit.SECONDS)
        .build()

    @Volatile private var cachedCatalog: Catalog? = null

    data class Catalog(
        val imageIdToName: Map<String, String>,
        val normalizedNameToOfficialName: Map<String, String>
    )

    /** Fetch or load the cached catalog once. Call from a background worker. */
    @Synchronized
    fun prepare(context: Context): Catalog {
        cachedCatalog?.let { return it }
        val cacheFile = File(context.filesDir, CACHE_NAME)
        val usableCache = cacheFile.exists() && cacheFile.length() > 0L
        val freshCache = usableCache && (System.currentTimeMillis() - cacheFile.lastModified() < MAX_CACHE_AGE_MS)

        if (!freshCache) {
            try {
                val request = Request.Builder()
                    .url(CATALOG_URL)
                    .header("User-Agent", "SmartFileRenamer-Android/0.8.0")
                    .header("Accept", "application/json")
                    .get()
                    .build()
                val body = client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) throw IOException("YGOPRODeck catalog request failed (${response.code}).")
                    if (text.isBlank() || !text.trimStart().startsWith("{")) throw IOException("YGOPRODeck returned an empty or invalid catalog.")
                    text
                }
                // Write atomically so an interrupted download cannot corrupt the previous cache.
                val temp = File(cacheFile.parentFile, "$CACHE_NAME.tmp")
                temp.writeText(body, Charsets.UTF_8)
                if (!temp.renameTo(cacheFile)) {
                    cacheFile.writeText(body, Charsets.UTF_8)
                    temp.delete()
                }
            } catch (e: Exception) {
                // A previously saved catalog remains usable offline, even if stale.
                if (!usableCache) throw IOException(
                    "Could not download the free YGOPRODeck card catalog. Check internet access and retry. No files were renamed. ${e.message ?: e.javaClass.simpleName}", e
                )
            }
        }

        val json = try { JSONObject(cacheFile.readText(Charsets.UTF_8)) }
        catch (e: Exception) { throw IOException("The cached YGOPRODeck catalog could not be read. Clear the app cache and retry.", e) }
        val data = json.optJSONArray("data") ?: throw IOException("YGOPRODeck catalog did not contain card data.")
        val imageIds = HashMap<String, String>(data.length() * 2)
        val names = HashMap<String, String>(data.length())
        for (i in 0 until data.length()) {
            val card = data.optJSONObject(i) ?: continue
            val officialName = card.optString("name").trim()
            if (officialName.isBlank()) continue
            names.putIfAbsent(normalize(officialName), officialName)
            val images = card.optJSONArray("card_images") ?: continue
            for (j in 0 until images.length()) {
                val image = images.optJSONObject(j) ?: continue
                val id = image.optLong("id", -1L)
                if (id > 0L) imageIds.putIfAbsent(id.toString(), officialName)
            }
        }
        if (imageIds.isEmpty()) throw IOException("YGOPRODeck catalog contained no usable card image IDs.")
        return Catalog(imageIds, names).also { cachedCatalog = it }
    }

    /** Returns an official card name only when the filename maps to a known image/card ID or exact name. */
    fun resolveBaseName(context: Context, filename: String): String? {
        val base = filename.substringBeforeLast('.', filename).trim()
        if (base.isBlank()) return null
        val catalog = prepare(context)
        if (base.all { it.isDigit() }) return catalog.imageIdToName[base]
        return catalog.normalizedNameToOfficialName[normalize(base)]
    }

    private fun normalize(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace("&", " and ")
        .replace(Regex("[^\\p{L}\\p{N}]+"), "")
}
