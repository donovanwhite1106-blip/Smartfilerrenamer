package com.example.smartfilerenamer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Background-work scaffold. Does not yet rename source files or produce an export archive. */
class RenameWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val uris = inputData.getStringArray("uris") ?: emptyArray()
        setForeground(foregroundInfo("Starting file scan…"))
        if (uris.isEmpty()) return@withContext Result.failure()
        uris.forEachIndexed { index, raw ->
            if (isStopped) return@withContext Result.retry()
            val name = Uri.parse(raw).lastPathSegment ?: "unknown-file"
            val suggestion = FileNameHeuristics.suggest(name)
            setProgress(androidx.work.workDataOf(
                "progress" to ((index + 1) * 100 / uris.size),
                "message" to "Analyzed ${index + 1}/${uris.size}: $suggestion"
            ))
        }
        Result.success(androidx.work.workDataOf("message" to "Initial scan complete; rename/export stages are not yet connected."))
    }

    private fun foregroundInfo(message: String): ForegroundInfo {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "renamer_jobs"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "File renaming jobs", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Smart File Renamer")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setProgress(0, 0, true)
            .build()
        return ForegroundInfo(4102, notification)
    }
}

object FileNameHeuristics {
    private val badChars = Regex("""[\\/:*?"<>|\p{Cntrl}]""")
    fun suggest(original: String): String {
        val base = original.substringAfterLast('/').substringBeforeLast('.', original)
        val cleaned = base.replace('_', ' ').replace('-', ' ')
            .replace(Regex("""\s+"""), " ").trim().replace(badChars, "")
        val ext = original.substringAfterLast('.', "")
        return cleaned.ifBlank { "identified file" }.take(120) + if ('.' in original && ext.isNotBlank()) ".$ext" else ""
    }
}
